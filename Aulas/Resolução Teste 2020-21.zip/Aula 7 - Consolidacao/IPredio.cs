﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula_7___Consolidacao
{
    public interface IPredio
    {

        int GetDiasConstrucao();
    }
}
