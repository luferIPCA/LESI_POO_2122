﻿/*
*	<copyright file="Aula_6_Pilares.cs" company="IPCA">
*		Copyright (c) 2021 All Rights Reserved
*	</copyright>
* 	<author>lufer</author>
*   <date>11/3/2021 10:01:16 PM</date>
*	<description></description>
**/
using System;

namespace Aula_6_Pilares
{
    /// <summary>
    /// Purpose:
    /// Created by: lufer
    /// Created on: 11/3/2021 10:01:16 PM
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class CarroLigeiro : Carro
    {
        #region Attributes
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public CarroLigeiro()
        {
        }

        #endregion

        #region Properties
        #endregion



        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~CarroLigeiro()
        {
        }
        #endregion

        #endregion
    }
}
